Rules available on our site:

www.pacmanvghosts.co.uk

Change the package names to your username on the site.

Edit the entrants code

Use the bash script to prepare the zip file for submission (Works on Windows under Git bash)